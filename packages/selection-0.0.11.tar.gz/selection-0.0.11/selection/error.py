class SelectionRuntimeError(Exception):
    pass
