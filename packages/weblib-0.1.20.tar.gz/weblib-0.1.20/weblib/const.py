NULL = object()
